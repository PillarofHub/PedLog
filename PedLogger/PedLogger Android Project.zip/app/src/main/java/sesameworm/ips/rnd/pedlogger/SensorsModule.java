package sesameworm.ips.rnd.pedlogger;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class SensorsModule {
    private static final String TAG = "SensorsModule";

    private String path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS) + "/PedLogger";

    private boolean isRunning;
    private StringBuilder sb;
    private String direction = "Stay";
    private long startTimestamp;

    // Sensor receiver
    private SensorManager sm;
    private float[] accData = new float[3], gyroData = new float[3], magData = new float[3];
    private float pressureData = 0;
    private float[] rotMatrix = new float[9];
    private float[] orientation = new float[3];

    private SensorEventListener sl = new SensorEventListener() {
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {}

        @Override
        public void onSensorChanged(SensorEvent event) {
            synchronized (sm) {
                if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                    for (int cnt = 0; cnt < event.values.length; cnt++) {
                        accData[cnt] = event.values[cnt];
                    }
                } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
                    for (int cnt = 0; cnt < event.values.length; cnt++) {
                        gyroData[cnt] = event.values[cnt];
                    }
                } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                    for (int cnt = 0; cnt < event.values.length; cnt++) {
                        magData[cnt] = event.values[cnt];
                    }
                } else if (event.sensor.getType() == Sensor.TYPE_PRESSURE) {
                    pressureData = event.values[0];
                }
            }

            // 가속 데이터와 자기장 데이터로 회전 매트릭스를 얻는다.
            SensorManager.getRotationMatrix(rotMatrix, null, accData, magData);
            // 회전 매트릭스로 방향 데이터를 얻는다.
            SensorManager.getOrientation(rotMatrix, orientation);
            // 방향 데이터의 순서 : azimuth, pitch, roll

            //"timestamp,accelX,accelY,accelZ,gyroX,gyroY,gyroZ,magX,magY,magZ,pressure,azimuth,pitch,roll,direction"
            sb.append(System.currentTimeMillis()).append(",")
                    .append(accData[0]).append(",").append(accData[1]).append(",").append(accData[2]).append(",")
                    .append(gyroData[0]).append(",").append(gyroData[1]).append(",").append(gyroData[2]).append(",")
                    .append(magData[0]).append(",").append(magData[1]).append(",").append(magData[2]).append(",")
                    .append(pressureData).append(",")
                    .append(orientation[0]).append(",").append(orientation[1]).append(",").append(orientation[2]).append(",")
                    .append(direction).append("\n");
        }
    };

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public void start() {
        if(isRunning) { Log.w(TAG, TAG + " is already running"); return; } isRunning = true;

        Sensor accSensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor gyroSensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        Sensor magSensor = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        Sensor pressureSensor = sm.getDefaultSensor(Sensor.TYPE_PRESSURE);
        sm.registerListener(sl, accSensor, SensorManager.SENSOR_DELAY_UI);
        sm.registerListener(sl, gyroSensor, SensorManager.SENSOR_DELAY_UI);
        sm.registerListener(sl, magSensor, SensorManager.SENSOR_DELAY_UI);
        sm.registerListener(sl, pressureSensor, SensorManager.SENSOR_DELAY_UI);

        startTimestamp = System.currentTimeMillis();
        sb = new StringBuilder();
        sb.append("timestamp,accelX,accelY,accelZ,gyroX,gyroY,gyroZ,magX,magY,magZ,pressure,azimuth,pitch,roll,direction").append("\n");
    }

    public void stop() {
        if(!isRunning) { Log.w(TAG, TAG + " is not running now"); return; } isRunning = false;
        sm.unregisterListener(sl);

        String outputStr = sb.toString();

        try {
            PrintWriter out = new PrintWriter(path + "/" + "pedLog_" + System.currentTimeMillis() + ".csv");
            out.print(outputStr);
            out.flush();
            out.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public SensorsModule(Context context) {
        sm = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        File pathFile = new File(path);
        if(!pathFile.exists()) pathFile.mkdirs();
    }
}
