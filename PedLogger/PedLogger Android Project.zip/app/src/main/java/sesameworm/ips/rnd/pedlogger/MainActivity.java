package sesameworm.ips.rnd.pedlogger;

import android.os.Bundle;
import android.view.View;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    SensorsModule sm;

    private ToggleButton tbMS;
    private ToggleButton tbStay;
    private ToggleButton tbFront;
    private ToggleButton tbBack;
    private ToggleButton tbLeft;
    private ToggleButton tbRight;

    public void onDirectionClick(View v) {
        ToggleButton[] btnArr = {tbStay, tbFront, tbBack, tbLeft, tbRight};
        String[] btnStr = {"Stay", "Front", "Back", "Left", "Right"};

        for(int cnt = 0; cnt < btnArr.length; cnt++) {
            ToggleButton btn = btnArr[cnt];
            if(btn.equals(v)) {
                sm.setDirection(btnStr[cnt]);
                btn.setChecked(true);
                continue;
            }
            btn.setChecked(false);
        }
    }

    public void onMasterClick(View v) {
        if(tbMS.isChecked()) {
            tbStay.setChecked(true);
            onDirectionClick(tbStay);

            tbFront.setEnabled(true);
            tbBack.setEnabled(true);
            tbStay.setEnabled(true);
            tbLeft.setEnabled(true);
            tbRight.setEnabled(true);

            sm.start();
            sm.setDirection("Stay");
        }
        else {
            sm.stop();
            sm.setDirection("Stay");
            tbStay.setChecked(true);
            onDirectionClick(tbStay);

            tbFront.setEnabled(false);
            tbBack.setEnabled(false);
            tbStay.setEnabled(false);
            tbLeft.setEnabled(false);
            tbRight.setEnabled(false);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        tbMS.setChecked(false);
        onMasterClick(tbMS);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tbMS = findViewById(R.id.masterSwitch);
        tbStay = findViewById(R.id.stay);
        tbFront = findViewById(R.id.front);
        tbBack = findViewById(R.id.back);
        tbLeft = findViewById(R.id.left);
        tbRight = findViewById(R.id.right);

        sm = new SensorsModule(getApplicationContext());
    }
}